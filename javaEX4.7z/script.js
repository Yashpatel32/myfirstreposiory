// const btn = document.querySelector('.login');
// const btn1 = document.querySelector('.login1');
// const show = document.querySelector('.show3');
// const show1 = document.querySelector('.show1');
// const form = document.querySelector('.form-h');
// const hidden = document.querySelector('.hidden');

// btn.addEventListener('click', function () {
//   form.classList.remove('hidden');
//   show.classList.add('hidden');
// });

// btn1.addEventListener('click', function () {
//   show1.classList.remove('hidden');
//   show.classList.add('hidden');
// });
